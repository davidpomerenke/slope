ownFiles = [
    //["myfile1.csv", "File 1" /*displayed text in the tool, should be short*/], 
    //["myfile2.csv", "File 2"], 
    //["myfile3.csv", "File 3"]
]